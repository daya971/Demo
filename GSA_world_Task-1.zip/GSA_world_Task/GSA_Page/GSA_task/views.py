from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .forms import LoginForm,RegistrationForm,TaskForm
from .models import Location
from django.shortcuts import render, redirect
import requests
from django.shortcuts import render, redirect
from django.contrib import messages

# import todo form and models

# from .forms import TodoForm
# from .models import Todo


# def index(request):
#     item_list = Todo.objects.order_by("-date")
#     if request.method == "POST":
#         form = TodoForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('add-task')
#     form = TodoForm()
#
#     page = {
#         "forms": form,
#         "list": item_list,
#         "title": "TODO LIST",
#     }
#     return render(request, 'add_task.html', page)
# def remove(request, item_id):
#     item = Todo.objects.get(id=item_id)
#     item.delete()
#     messages.info(request, "item removed !!!")
#     return redirect('todo')
# Create your views here.
# Home page
def index_page(request):
    return render(request, 'index.html')

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'index.html')  # Redirect to a success page
    else:
        form = RegistrationForm()
    return render(request, 'register.html', {'form': form})

def save_location(request):
    if request.method == 'POST':
        address = request.POST['address']
        # Call Google Maps API to get latitude and longitude
        api_key = '663f235f9a843703175512uza70f147'
        url = f'https://geocode.maps.co/search?q={address}&api_key={api_key}'
        response = requests.get(url)
        data = response.json()
        if data['status'] == 'OK':
            lat = data['results'][0]['geometry']['location']['lat']
            lng = data['results'][0]['geometry']['location']['lng']
            # Save address, latitude, and longitude to the database
            location = Location.objects.create(address=address, latitude=lat, longitude=lng)
            # return render(request, 'success.html', {'location': location})
        else:
            print('something wrong api')
            # return render(request, 'error.html')
    else:
        return render(request, 'index.html')

# signup page
# def user_signup(request):
#     if request.method == 'POST':
#         form = SignupForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('login')
#     else:
#         form = SignupForm()
#     return render(request, 'signup.html', {'form': form})

# login page
def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)
                return redirect('add-task')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})





def add_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('task-list')  # Redirect to task list view after adding task
    else:
        form = TaskForm()
    return render(request, 'add_task.html', {'form': form})
# def add_task(request):
#     if request.method == 'POST':
#         form = TaskForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('task-list')  # Redirect to task list view after adding task
#     else:
#         form = TaskForm()
#     return render(request, 'add_task.html', {'form': form})
# logout page
def user_logout(request):
    logout(request)
    return redirect('login')